import React from 'react';

const Dashboard = () => {
  return <div>Dashboard Page</div>;
};

export default Dashboard;